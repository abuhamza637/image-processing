%ABS Datafile overload
