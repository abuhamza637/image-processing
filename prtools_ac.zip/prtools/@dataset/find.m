%FIND Find nonzero elements in dataset
