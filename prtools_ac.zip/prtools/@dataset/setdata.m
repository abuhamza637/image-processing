%SETDATA Reset data and feature labels of dataset
%
%   A = SETDATA(A,DATA,FEATLAB)
%
% The data in the dataset A is replaced by DATA (dataset or double) The
% numbers of objects in A and DATA should be equal.  The feature labels of
% A are replaced by FEATLAB, or, if not supplied and DATA is a dataset by
% the feature labels of DATA.  Labels and class probabilities of A are
% preserved.
