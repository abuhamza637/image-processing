%SORT Sort in ascending order. Dataset overload
