%XOR Dataset overload
