%VAR Dataset overload
%
%   [V,U] = VAR(A,W)
%
% Computes variance V and mean U in a single run for consistency with datafile overload.
