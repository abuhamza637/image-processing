%SQRT Dataset overload
