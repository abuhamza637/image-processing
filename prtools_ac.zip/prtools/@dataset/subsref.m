%SUBSREF Subscripted reference. Dataset overload
%
% 
% $Id: subsref.m,v 1.18 2010/01/24 00:04:18 duin Exp $
