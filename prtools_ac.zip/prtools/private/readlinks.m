%READLINKS Read links stored for PRTools distribution
