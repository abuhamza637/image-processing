%NEWLINE The platform dependent newline character
%
% c = newline
