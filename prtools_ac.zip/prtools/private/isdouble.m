%ISDOUBLE Test on doubles
